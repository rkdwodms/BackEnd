package Pack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


// app/1000

@RestController
@RequestMapping("/app")
public class AppController {
	@Autowired 
	RestTemplate restTemplate;
	
	@GetMapping("/{appNum}")
	@HystrixCommand(fallbackMethod = "tiger")
	public String f1(@PathVariable String appNum) {
		
		
		// = new RestTemplate();
		String str = restTemplate.getForObject(
				//"http://localhost:8082/bpp/3000", 
				"http://Service02/bpp/3000",
				String.class);

		// 문자열을 리턴 받음.
		return "AppController : " + appNum + 
				"<br/>" + str;
	}
	
	public String tiger(String s) {
		return s + "저쪽에서 응답 안함........";
	}
}






