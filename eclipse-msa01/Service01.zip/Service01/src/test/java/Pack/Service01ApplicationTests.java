package Pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
