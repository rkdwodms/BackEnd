package Pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apple01Application {

	public static void main(String[] args) {
		SpringApplication.run(Apple01Application.class, args);
	}

}
