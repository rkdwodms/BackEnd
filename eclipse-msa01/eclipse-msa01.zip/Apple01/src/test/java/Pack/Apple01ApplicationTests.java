package Pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apple01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
