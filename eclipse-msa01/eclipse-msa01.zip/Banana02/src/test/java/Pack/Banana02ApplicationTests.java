package Pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Banana02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
