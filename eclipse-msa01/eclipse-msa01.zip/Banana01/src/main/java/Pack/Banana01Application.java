package Pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Banana01Application {

	public static void main(String[] args) {
		SpringApplication.run(Banana01Application.class, args);
	}

}
